"""HTTP integration checks using synthetic files; never changes the saved model."""
import argparse
from http.cookiejar import CookieJar
from io import BytesIO
import json
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import build_opener, HTTPCookieProcessor, Request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import numpy as np
from PIL import Image
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen.canvas import Canvas
from documents import Page, read_pages, on_white
from orientation import OrientationModel, ANGLES
from train import examples


class Client:
    def __init__(self, url):
        self.url = url
        self.opener = build_opener(HTTPCookieProcessor(CookieJar()))
        self.token = self.call('/api/state')['token']

    def call(self, route, data=None, raw=False, headers=None):
        request_headers = headers or {}
        if data is not None:
            request_headers = dict(request_headers, **{'X-FileLab': self.token})
            if not isinstance(data, bytes):
                data = json.dumps(data).encode()
                request_headers['Content-Type'] = 'application/json'
        request = Request(self.url + route, data=data, headers=request_headers)
        with self.opener.open(request, timeout=90) as response:
            body = response.read()
            return body if raw else json.loads(body)

    def upload(self, files, target=None):
        boundary = 'FILELAB-VERIFY-BOUNDARY'
        chunks = []
        for name, data in files:
            chunks.append((f'--{boundary}\r\nContent-Disposition: form-data; name="files"; filename="{name}"\r\nContent-Type: application/octet-stream\r\n\r\n').encode() + data + b'\r\n')
        body = b''.join(chunks) + f'--{boundary}--\r\n'.encode()
        return self.call('/api/upload' + ('?replace=' + target if target else ''), body,
                         headers={'Content-Type': f'multipart/form-data; boundary={boundary}'})

    def pdf(self, comparison, mode='standard', spec=''):
        return self.call('/api/pdf?' + urlencode(dict(mode=mode, revision=comparison['revision'], range=spec)), raw=True)


def expect_error(fn, code=400):
    try:
        fn()
    except HTTPError as error:
        assert error.code == code
        assert json.loads(error.read())['error']
    else:
        raise AssertionError('Expected rejected request')


def verify(url, out):
    client, other = Client(url), Client(url)
    state = client.call('/api/demo', {})
    assert len(state['pages']) == 4
    assert [p['rotation'] for p in state['pages'][:3]] == [0, 270, 180]
    assert [p['predicted'] for p in state['pages'][:3]] == [0, 90, 180]
    assert 'Бұлыңғыр' in state['pages'][3]['notes'][0]
    assert other.call('/api/state')['pages'] == []
    expect_error(lambda: other.call('/api/image?id=' + state['pages'][0]['id']))
    state = client.call('/api/delete', {'id': state['pages'][3]['id']})
    ids = [p['id'] for p in state['pages']]
    state = client.call('/api/reorder', {'ids': [ids[2], ids[0], ids[1]]})
    comparison = client.call('/api/compare', {'range': '', 'limit': '0,23'})
    assert comparison['recommended'] == 'standard'
    result = client.pdf(comparison)
    assert len(result) == comparison['sizes']['standard']
    pdf_path = out / 'demo-three-pages.pdf'
    pdf_path.write_bytes(result)
    assert len(PdfReader(BytesIO(result)).pages) == 3
    # Compare each rendered PDF against its expected corrected source, including order.
    decoded = read_pages(pdf_path)
    expected_paths = ['03-upside-down.png', '01-upright.png', '02-sideways.png']
    rotations = [180, 0, 270]
    errors = []
    for page, filename, rotation in zip(decoded, expected_paths, rotations):
        source = read_pages(ROOT / 'demo' / filename)[0]
        source.rotation = rotation
        expected = np.asarray(on_white(source.image(500)), dtype=float)
        actual_image = on_white(page.image(500)).resize((expected.shape[1], expected.shape[0]))
        mae = float(np.abs(expected - np.asarray(actual_image, dtype=float)).mean())
        assert mae < 8, (filename, mae)
        assert actual_image.height > actual_image.width
        errors.append(round(mae, 4))
    reimported = client.upload([('roundtrip.pdf', result)])
    assert len(reimported['pages']) == 6
    split_comparison = client.call('/api/compare', {'range': '4, 6', 'limit': '5'})
    split = client.pdf(split_comparison, 'original', '4, 6')
    assert len(PdfReader(BytesIO(split)).pages) == 2
    (out / 'split-two-pages.pdf').write_bytes(split)
    for kind, expected in [('jpg', 'JPEG'), ('png', 'PNG')]:
        image_data = client.call('/api/image?' + urlencode({'id': reimported['pages'][3]['id'], 'format': kind}), raw=True)
        assert Image.open(BytesIO(image_data)).format == expected
        (out / ('page.' + kind)).write_bytes(image_data)
    vector = BytesIO()
    canvas = Canvas(vector)
    canvas.drawString(80, 750, 'FILELAB SELECTABLE TEXT')
    canvas.showPage()
    canvas.save()
    (out / 'text-source.pdf').write_bytes(vector.getvalue())
    merged = client.upload([('text-source.pdf', vector.getvalue()), ('second.pdf', vector.getvalue())])
    assert len(merged['pages']) == 8
    compare_text = client.call('/api/compare', {'range': '7-8', 'limit': '5'})
    text_pdf = client.pdf(compare_text, 'original', '7-8')
    assert all('FILELAB SELECTABLE TEXT' in p.extract_text() for p in PdfReader(BytesIO(text_pdf)).pages)
    (out / 'text-preserved.pdf').write_bytes(text_pdf)
    client.call('/api/rotate', {'id': merged['pages'][6]['id'], 'angle': 90})
    expect_error(lambda: client.pdf(compare_text, 'original', '7-8'))
    rotated = client.call('/api/compare', {'range': '7', 'limit': '5'})
    rotated_pdf = PdfReader(BytesIO(client.pdf(rotated, 'original', '7')))
    assert rotated_pdf.pages[0].rotation == 90
    assert 'FILELAB SELECTABLE TEXT' in rotated_pdf.pages[0].extract_text()
    # True type verification and partial-batch preservation.
    invalid = client.upload([('broken.pdf', b'not a pdf'), ('wrong.jpg', (ROOT / 'demo/01-upright.png').read_bytes()), ('valid.png', (ROOT / 'demo/01-upright.png').read_bytes())])
    assert len(invalid['errors']) == 2 and len(invalid['pages']) == 9
    (out / 'broken.pdf').write_bytes(b'not a pdf')
    writer = PdfWriter()
    for _ in range(41):
        writer.add_blank_page(width=595, height=842)
    too_many = BytesIO()
    writer.write(too_many)
    (out / 'too-many-pages.pdf').write_bytes(too_many.getvalue())
    rejected = client.upload([('too-many-pages.pdf', too_many.getvalue())])
    assert '40' in rejected['errors'][0] and len(rejected['pages']) == 9
    writer = PdfWriter()
    writer.add_blank_page(width=595, height=842)
    writer.encrypt('secret')
    encrypted = BytesIO()
    writer.write(encrypted)
    rejected = client.upload([('locked.pdf', encrypted.getvalue())])
    assert 'Құпиясөз' in rejected['errors'][0]
    large_image = BytesIO()
    Image.new('RGB', (5001, 5000), 'white').save(large_image, 'PNG')
    rejected = client.upload([('too-large.png', large_image.getvalue())])
    assert '24' in rejected['errors'][0]
    oversized = client.upload([('over64.pdf', b'%PDF-' + b'0' * (64*1048576))])
    assert '64' in oversized['errors'][0]
    no_fit = client.call('/api/compare', {'range': '', 'limit': '0,001'})
    assert no_fit['recommended'] is None and not any(no_fit['fits'].values())
    for spec in ['0', '1-99', '3-1', 'тест']:
        expect_error(lambda: client.call('/api/compare', {'range': spec, 'limit': '1'}))
    for limit in ['0', 'nan', '-1', 'abc']:
        expect_error(lambda: client.call('/api/compare', {'range': '', 'limit': limit}))
    before = client.call('/api/state')
    replaced = client.upload([('replacement.png', (ROOT / 'demo/01-upright.png').read_bytes())], before['pages'][0]['id'])
    assert len(replaced['pages']) == 9 and replaced['pages'][0]['title'] == 'replacement.png'
    failed_replace = client.upload([('broken.pdf', b'broken')], replaced['pages'][0]['id'])
    assert failed_replace['pages'][0]['id'] == replaced['pages'][0]['id']
    dark = BytesIO()
    Image.new('RGB', (100, 100), (30, 30, 30)).save(dark, 'PNG')
    dark_state = other.upload([('dark.png', dark.getvalue())])
    assert 'Тым қараңғы' in dark_state['pages'][0]['notes']
    assert dark_state['pages'][0]['orientation'] == 'Қолмен тексеріңіз'
    expect_error(lambda: client.call('/api/clear', {}, headers={'Origin':'https://example.invalid'}))
    # Verify CSRF token enforcement without altering the valid client.
    token = client.token
    client.token = 'incorrect'
    expect_error(lambda: client.call('/api/clear', {}), 403)
    client.token = token
    assert client.call('/api/clear', {})['pages'] == []
    assert len(other.call('/api/state')['pages']) == 1
    other.call('/api/clear', {})
    model = OrientationModel.load()
    matrix = np.zeros((4, 4), dtype=int)
    for _, image, label in examples(1000, 48, ('test_summary', 'test_tasks', 'test_sparse', 'test_diagram')):
        predicted, _ = model.predict(image)
        matrix[label, ANGLES.index(predicted)] += 1
    assert int(matrix.trace()) == 144
    report = dict(passed=True, sizes=comparison['sizes'], recommended=comparison['recommended'],
                  page_order=expected_paths, render_mean_absolute_errors=errors,
                  model_correct=int(matrix.trace()), model_test_images=192,
                  confusion_matrix=matrix.tolist(),
                  checked=['demo orientation', 'blur', 'reorder', 'real byte sizes', 'rendered page order',
                           'PDF roundtrip', 'range export', 'JPG/PNG', 'multi-PDF merge', 'selectable text',
                           'PDF rotation', 'stale export rejection', 'invalid type', 'partial upload',
                           '41 pages', 'encrypted PDF', '24MP limit', '64MiB limit', 'no fitting preset',
                           'bad ranges', 'bad size limits', 'atomic replacement', 'dark page',
                           'session isolation', 'clear', 'origin and CSRF checks', 'unchanged model evaluation'])
    (out / 'verification.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--url')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    out = args.output or Path(tempfile.mkdtemp(prefix='filelab-tests-'))
    out.mkdir(exist_ok=True, parents=True)
    if args.url:
        verify(args.url, out)
    else:
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            port = sock.getsockname()[1]
        process = subprocess.Popen([sys.executable, str(Path(__file__).with_name('server.py')), '--port', str(port)], stdout=subprocess.DEVNULL)
        try:
            url = f'http://127.0.0.1:{port}'
            for _ in range(50):
                try:
                    with socket.create_connection(('127.0.0.1', port), timeout=.3):
                        break
                except OSError:
                    time.sleep(.1)
            verify(url, out)
        finally:
            process.terminate()
            process.wait(timeout=10)
    print('Verification artifacts:', out)


if __name__ == '__main__':
    main()
