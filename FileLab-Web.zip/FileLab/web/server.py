"""Offline, loopback-only FileLab web adapter. No external service or web framework."""
from __future__ import annotations

import argparse
import atexit
from dataclasses import dataclass, field, replace
from email.parser import BytesParser
from email.policy import default
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, HTTPServer
from io import BytesIO
import json
import math
from pathlib import Path
import secrets
import shutil
import sys
import tempfile
import time
from urllib.parse import parse_qs, urlsplit
import webbrowser

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from documents import (MAX_PAGES, MAX_PIXELS, MAX_SOURCE_BYTES, MIB, PRESETS,
                       Page, create_pdf, image_bytes, on_white, page_range,
                       quality_notes, read_pages)
from orientation import OrientationModel
from PIL import Image

STATIC = Path(__file__).with_name("static")
SESSION_LIMIT = 96 * MIB
TTL = 2 * 60 * 60
RUNTIME = Path(tempfile.mkdtemp(prefix="filelab-web-"))
atexit.register(lambda: shutil.rmtree(RUNTIME, ignore_errors=True))
MODEL = OrientationModel.load()
SESSIONS: dict[str, Session] = {}


@dataclass
class Item:
    page: Page
    id: str = field(default_factory=lambda: secrets.token_hex(8))
    notes: list[str] = field(default_factory=list)
    orientation: str = ""
    predicted: int = 0
    vote: float = 0

    def inspect(self, orient=True):
        self.notes = quality_notes(self.page.image(500))
        if orient:
            image = on_white(self.page.image(600))
            histogram = image.convert("L").histogram()
            ink = sum(histogram[:165]) / (image.width * image.height)
            self.predicted, self.vote = MODEL.predict(image)
            if ink < 0.017 or self.vote < 0.65:
                self.orientation = "Қолмен тексеріңіз"
            elif self.predicted:
                self.page.rotation = (self.page.rotation - self.predicted) % 360
                self.orientation = "Бағыты түзетілді"
            else:
                self.orientation = "Бағыты дұрыс"

    def public(self):
        return dict(id=self.id, title=self.page.title, rotation=self.page.rotation,
                    notes=self.notes, orientation=self.orientation,
                    predicted=self.predicted, vote=round(self.vote, 4),
                    kind="PDF" if self.page.index is not None else "Сурет")


@dataclass
class Session:
    id: str = field(default_factory=lambda: secrets.token_hex(24))
    token: str = field(default_factory=lambda: secrets.token_hex(24))
    items: list[Item] = field(default_factory=list)
    revision: int = 0
    exports: dict = field(default_factory=dict)
    touched: float = field(default_factory=time.time)

    @property
    def directory(self):
        directory = RUNTIME / self.id
        directory.mkdir(exist_ok=True)
        return directory

    def invalidate(self):
        self.revision += 1
        self.exports.clear()
        used = {item.page.path for item in self.items}
        for path in self.directory.iterdir():
            if path not in used:
                path.unlink(missing_ok=True)

    def state(self):
        return dict(pages=[item.public() for item in self.items], revision=self.revision,
                    token=self.token, sourceBytes=self.source_bytes())

    def source_bytes(self):
        return sum({id(i.page.data): len(i.page.data) for i in self.items}.values())

    def item(self, id):
        for item in self.items:
            if item.id == id:
                return item
        raise ValueError("Таңдалған бет табылмады. Беттер тізімін жаңартыңыз.")

    def add(self, name, data, target=None):
        name = name.replace("\\", "/").split("/")[-1][:180]
        suffix = Path(name).suffix.lower()
        if suffix not in {".jpg", ".jpeg", ".png", ".pdf"}:
            raise ValueError("JPG, JPEG, PNG немесе PDF файлын таңдаңыз.")
        if len(data) > MAX_SOURCE_BYTES:
            raise ValueError("Бір файлдың көлемі 64 МиБ-тан аспауы керек.")
        if self.source_bytes() + len(data) > SESSION_LIMIT:
            raise ValueError("Сессиядағы файлдардың жалпы шегі — 96 МиБ.")
        if suffix == ".pdf":
            if not data.startswith(b"%PDF-"):
                raise ValueError("Файлдың мазмұны PDF түріне сәйкес емес.")
        else:
            try:
                with Image.open(BytesIO(data)) as image:
                    expected = "PNG" if suffix == ".png" else "JPEG"
                    if image.format != expected:
                        raise ValueError("Файл кеңейтімі мен нақты сурет түрі сәйкес емес.")
                    if image.width * image.height > MAX_PIXELS:
                        raise ValueError("Суреттің ажыратымдылығы 24 мегапиксельден аспауы керек.")
                    image.verify()
            except ValueError:
                raise
            except Exception:
                raise ValueError("Сурет ашылмады: файл бүлінген немесе сурет түрі дұрыс емес.")
        path = self.directory / (secrets.token_hex(8) + suffix)
        try:
            path.write_bytes(data)
            try:
                pages = read_pages(path)
            except ValueError as error:
                if any(word in str(error) for word in ("PDF құжатында", "Құпиясөз", "МиБ", "мегапиксель")):
                    raise
                raise ValueError("Құжат ашылмады: файл бүлінген немесе пішімі қолдау таппайды.")
            except Exception:
                raise ValueError("Құжат ашылмады: файл бүлінген немесе толық жүктелмеген.")
            if len(self.items) + len(pages) - bool(target) > MAX_PAGES:
                raise ValueError(f"Бір сессияға ең көбі {MAX_PAGES} бет қосылады.")
            if target and len(pages) != 1:
                raise ValueError("Бетті ауыстыру үшін бір сурет немесе бір беттік PDF таңдаңыз.")
            added = []
            for page in pages:
                item = Item(page)
                # Keep the disk path private; display the original upload name.
                item.inspect()
                added.append(item)
            for item in added:
                TITLES[item.id] = name if item.page.index is None else f"{name} · {item.page.index + 1}-бет"
            if target:
                position = self.items.index(self.item(target))
                TITLES.pop(self.items[position].id, None)
                self.items[position:position + 1] = added
            else:
                self.items.extend(added)
            self.invalidate()
            return len(added)
        except Exception:
            path.unlink(missing_ok=True)
            raise

    def compare(self, spec, limit):
        indices = page_range(spec, len(self.items))
        if not indices:
            raise ValueError("Алдымен кемінде бір бет қосыңыз.")
        try:
            bound = float(str(limit).replace(",", "."))
            if not math.isfinite(bound) or bound <= 0:
                raise ValueError()
        except (ValueError, TypeError):
            raise ValueError("Көлем шегін оң санмен жазыңыз. Мысалы: 0,23.")
        key = tuple(indices)
        if self.exports.get("key") != key:
            pages = [self.items[i].page for i in indices]
            variants = {mode: create_pdf(pages, mode) for mode in PRESETS}
            self.exports = dict(key=key, variants=variants)
        sizes = {mode: len(data) for mode, data in self.exports["variants"].items()}
        fits = {mode: size <= bound * MIB for mode, size in sizes.items()}
        recommended = next((mode for mode in PRESETS if fits[mode]), None)
        return dict(sizes=sizes, fits=fits, recommended=recommended,
                    revision=self.revision, count=len(indices), range=spec)


TITLES = {}


class Handler(BaseHTTPRequestHandler):
    server_version = "FileLab/1.0"

    def log_message(self, *_):
        pass  # Do not log private filenames or session cookies.

    def reply(self, data, mime="application/json; charset=utf-8", status=200, filename=None):
        if isinstance(data, dict):
            data = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' blob:; style-src 'self'; script-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        if hasattr(self, "session"):
            self.send_header("Set-Cookie", f"filelab={self.session.id}; Path=/; HttpOnly; SameSite=Strict")
        if filename:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.end_headers()
        self.wfile.write(data)

    def prepare(self):
        host = f"127.0.0.1:{self.server.server_port}"
        if self.headers.get("Host") != host:
            raise ValueError("Қолданбаны көрсетілген 127.0.0.1 мекенжайы арқылы ашыңыз.")
        origin = self.headers.get("Origin")
        if origin and origin != "http://" + host:
            raise ValueError("Басқа сайттан жіберілген сұрауға рұқсат жоқ.")
        if self.headers.get("Sec-Fetch-Site") == "cross-site":
            raise ValueError("Басқа сайттан жіберілген сұрауға рұқсат жоқ.")
        cookie = SimpleCookie(self.headers.get("Cookie", ""))
        id = cookie["filelab"].value if "filelab" in cookie else ""
        session = SESSIONS.get(id)
        if session is None:
            if len(SESSIONS) >= 8:
                raise ValueError("Ашық сессиялар шегіне жетті. Әрекетсіз сессиялар екі сағаттан соң жабылады; қажет болса серверді қайта іске қосыңыз.")
            session = Session()
            SESSIONS[session.id] = session
        self.session = session
        session.touched = time.time()
        self.route = urlsplit(self.path)
        self.query = {key: values[0] for key, values in parse_qs(self.route.query).items()}

    def state(self, **extra):
        data = self.session.state()
        for page in data["pages"]:
            page["title"] = TITLES.get(page["id"], page["title"])
        return dict(data, **extra)

    def do_GET(self):
        try:
            self.prepare()
            path = self.route.path
            if path in {"/", "/app.js", "/style.css"}:
                file = STATIC / ({"/": "index.html"}.get(path, path[1:]))
                mime = {".html": "text/html", ".js": "text/javascript", ".css": "text/css"}[file.suffix]
                self.reply(file.read_bytes(), mime + "; charset=utf-8")
            elif path == "/api/state":
                self.reply(self.state())
            elif path == "/api/image":
                item = self.session.item(self.query.get("id"))
                original = self.query.get("original") == "1"
                page = replace(item.page, rotation=0) if original else item.page
                kind = self.query.get("format")
                if kind in {"jpg", "png"}:
                    self.reply(image_bytes(page, "." + kind), "image/" + ("jpeg" if kind == "jpg" else kind), filename="FileLab-page." + kind)
                else:
                    image = on_white(page.image(180 if self.query.get("thumb") == "1" else 1000))
                    stream = BytesIO()
                    image.save(stream, "JPEG", quality=88)
                    self.reply(stream.getvalue(), "image/jpeg")
            elif path == "/api/pdf":
                if int(self.query.get("revision", -1)) != self.session.revision:
                    raise ValueError("Беттер өзгерді. Көлемдерді қайта салыстырыңыз.")
                mode = self.query.get("mode")
                if mode not in PRESETS:
                    raise ValueError("PDF сапа режимін таңдаңыз.")
                indices = tuple(page_range(self.query.get("range", ""), len(self.session.items)))
                if self.session.exports.get("key") != indices:
                    raise ValueError("Бет аралығы өзгерді. Көлемдерді қайта салыстырыңыз.")
                data = self.session.exports["variants"][mode]
                self.reply(data, "application/pdf", filename="FileLab-" + mode + ".pdf")
            else:
                self.reply({"error": "Бұл мекенжай табылмады."}, status=404)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except ValueError as error:
            self.reply({"error": str(error)}, status=400)
        except Exception:
            self.reply({"error": "Бетті өңдеу мүмкін болмады. Файлды тексеріп, қайталап көріңіз."}, status=500)

    def do_POST(self):
        try:
            self.prepare()
            if self.headers.get("X-FileLab") != self.session.token:
                self.reply({"error": "Сессия жаңарды. Браузер бетін жаңартыңыз."}, status=403)
                return
            length = int(self.headers.get("Content-Length", "0"))
            max_length = SESSION_LIMIT + MIB if self.route.path == "/api/upload" else 64 * 1024
            if length < 0 or length > max_length:
                raise ValueError("Сұрау тым үлкен. Файлдарды бөліп қосыңыз; сессия шегі — 96 МиБ.")
            self.connection.settimeout(60)
            body = self.rfile.read(length)
            if len(body) != length:
                raise ValueError("Файл толық жүктелмеді. Қайталап көріңіз.")
            session = self.session
            path = self.route.path
            if path == "/api/upload":
                content_type = self.headers.get("Content-Type", "")
                if not content_type.startswith("multipart/form-data;"):
                    raise ValueError("Файл жүктеу пішімі дұрыс емес.")
                message = BytesParser(policy=default).parsebytes(("Content-Type: " + content_type + "\r\nMIME-Version: 1.0\r\n\r\n").encode() + body)
                files = [part for part in message.iter_parts() if part.get_filename()]
                if not files:
                    raise ValueError("Қосатын файл таңдалмады.")
                target = self.query.get("replace")
                if target and len(files) != 1:
                    raise ValueError("Бетті ауыстыру үшін бір файл таңдаңыз.")
                errors, added = [], 0
                for part in files:
                    try:
                        added += session.add(part.get_filename(), part.get_payload(decode=True), target)
                    except Exception as error:
                        reason = str(error) if isinstance(error, ValueError) else "Файлды оқу мүмкін болмады."
                        errors.append(f"{part.get_filename()}: {reason}")
                self.reply(self.state(errors=errors, added=added))
                return
            try:
                data = json.loads(body or b"{}")
            except Exception:
                raise ValueError("Сұрау пішімі дұрыс емес.")
            if not isinstance(data, dict):
                raise ValueError("Сұрау пішімі дұрыс емес.")
            if path == "/api/demo":
                errors, added = [], 0
                for file in sorted((ROOT / "demo").glob("0[1-4]-*.png")):
                    try:
                        added += session.add(file.name, file.read_bytes())
                    except ValueError as error:
                        errors.append(f"{file.name}: {error}")
                self.reply(self.state(errors=errors, added=added))
            elif path == "/api/clear":
                for item in session.items:
                    TITLES.pop(item.id, None)
                session.items.clear()
                session.invalidate()
                self.reply(self.state())
            elif path == "/api/compare":
                self.reply(session.compare(str(data.get("range", "")), data.get("limit")))
            elif path == "/api/reorder":
                ids = data.get("ids", [])
                if len(ids) != len(session.items) or set(ids) != {item.id for item in session.items}:
                    raise ValueError("Беттер реті сәйкес емес. Тізімді жаңартыңыз.")
                session.items = [session.item(id) for id in ids]
                session.invalidate()
                self.reply(self.state())
            elif path in {"/api/rotate", "/api/delete", "/api/quality", "/api/orient"}:
                item = session.item(data.get("id"))
                if path == "/api/delete":
                    session.items.remove(item)
                    TITLES.pop(item.id, None)
                elif path == "/api/rotate":
                    angle = data.get("angle")
                    if angle not in (-90, 90):
                        raise ValueError("Бетті тек 90° қадаммен бұруға болады.")
                    item.page.rotation = (item.page.rotation + angle) % 360
                    item.orientation = "Қолмен бұрылды"
                else:
                    item.inspect(orient=path == "/api/orient")
                session.invalidate()
                self.reply(self.state())
            else:
                self.reply({"error": "Әрекет табылмады."}, status=404)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except ValueError as error:
            self.reply({"error": str(error)}, status=400)
        except Exception:
            self.reply({"error": "Өңдеу аяқталмады. Қосылған беттер сақталды; қайталап көріңіз."}, status=500)


def clean_expired():
    for id, session in list(SESSIONS.items()):
        if time.time() - session.touched > TTL:
            for item in session.items:
                TITLES.pop(item.id, None)
            shutil.rmtree(RUNTIME / id, ignore_errors=True)
            del SESSIONS[id]


def main():
    parser = argparse.ArgumentParser(description="FileLab жергілікті веб-нұсқасы")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--open", action="store_true")
    args = parser.parse_args()
    # Serial request handling also protects the non-thread-safe PDFium library.
    with HTTPServer(("127.0.0.1", args.port), Handler) as server:
        server.timeout = 20
        url = f"http://127.0.0.1:{server.server_port}"
        print(f"FileLab: {url}", flush=True)
        print(f"Temporary session root: {RUNTIME}", flush=True)
        if args.open:
            webbrowser.open(url)
        try:
            while True:
                clean_expired()
                server.handle_request()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
