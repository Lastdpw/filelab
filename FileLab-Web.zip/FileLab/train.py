"""Generate synthetic pages, train, and evaluate with separate base pages."""

import csv
import json
import random
from functools import lru_cache
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

from orientation import ANGLES, MODEL_PATH, OrientationModel, features, rotate


ROOT = Path(__file__).parent
FONT = ROOT / "fonts" / "DejaVuSans.ttf"
SENTENCES = (
    "Деректерді өңдеу және тексеру жоспары",
    "Тәжірибе нәтижелерін кестеге түсіріңіз.",
    "Әр сұраққа қысқа түсіндірме жазыңыз.",
    "Таңдалған әдістің шектеулерін белгілеңіз.",
    "Келесі бөлімде практикалық мысал берілген.",
    "Қорытындыны өз сөзіңізбен тұжырымдаңыз.",
    "Зерттеу тобы нәтижені қайта тексерді.",
    "Бастапқы шарттарды мұқият салыстырыңыз.",
    "Жоба нәтижесі үш мысалмен көрсетілді.",
    "Бүгінгі сабақтың тақырыбы мен мақсаты",
    "Мәндерді есептеп, өлшем бірлігін көрсетіңіз.",
    "Көрсеткіштерді салыстырып, кестені толтырыңыз.",
)


@lru_cache(maxsize=24)
def font(size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(FONT), size=size)


def page_image(seed: int, layout: str, clean: bool = False) -> Image.Image:
    rng = random.Random(seed)
    width, height = rng.choice(((550, 760), (530, 750), (560, 720), (570, 800)))
    background = rng.randrange(222, 256)
    image = Image.new("RGB", (width, height), (background, background, min(background + 3, 255)))
    draw = ImageDraw.Draw(image)
    if layout == "test_diagram":
        x, y = width // 2, height // 2
        draw.ellipse((x - 110, y - 110, x + 110, y + 110), outline="#244252", width=7)
        draw.line((x, y - 30, x, y + 30), fill="#244252", width=4)
        draw.line((x - 10, y - 18, x, y - 30, x + 10, y - 18), fill="#244252", width=4)
        return image
    margin = rng.randrange(38, 70)
    position = rng.randrange(36, 76)
    title = font(rng.randrange(22, 31))
    body = font(rng.randrange(14, 19))
    color = (rng.randrange(20, 78),) * 3
    text_bank = SENTENCES[8:] if layout.startswith("test") else SENTENCES[:8]
    title_text = {
        "train_report": "Тәжірибе есебі", "train_notes": "Дәріс жазбалары",
        "train_exercise": "Зертхана жұмысы", "test_summary": "Жоба қорытындысы",
        "test_tasks": "Оқу тапсырмалары", "test_sparse": "Сызба",
    }[layout]
    draw.text((margin, position), title_text, fill=color, font=title)
    position += 48
    if layout == "test_sparse":
        draw.ellipse((width // 2 - 74, height // 2 - 74, width // 2 + 74, height // 2 + 74),
                     outline=color, width=4)
        return image
    if layout in ("train_report", "test_summary"):
        draw.line((margin, position, width - margin, position), fill=(71, 128, 128), width=2)
        position += 20
    count = rng.randrange(10, 23)
    for index in range(count):
        words = rng.choice(text_bank).split()
        line = " ".join(words[:rng.randrange(2, len(words) + 1)])
        if layout in ("train_exercise", "test_tasks") and index % 4 == 0:
            line = f"{index // 4 + 1}. {line}"
        indent = rng.randrange(0, 24) if layout == "train_notes" else 0
        while draw.textlength(line, font=body) > width - 2 * margin - indent:
            line = line.rsplit(" ", 1)[0]
        draw.text((margin + indent, position), line, fill=color, font=body)
        position += rng.randrange(19, 28) + (rng.randrange(8, 19) if index % 4 == 3 else 0)
        if position > height - 85:
            break
    if layout in ("train_report", "test_summary") and position < height - 105:
        draw.rectangle((margin, position + 12, width - margin * 2, position + 72), outline=color, width=2)
        draw.line((margin, position + 42, width - margin * 2, position + 42), fill=color, width=2)
    draw.text((margin, height - 34), "ЖАСАНДЫ ҮЛГІ", fill="#426e74", font=font(10))
    draw.text((width - margin - 19, height - 37), str(seed % 9 + 1), fill=color, font=body)
    if not clean and rng.random() < 0.28:
        image = image.filter(ImageFilter.GaussianBlur(rng.uniform(0.5, 1.3)))
    return image


def examples(start: int, count: int, layouts: tuple[str, ...]):
    for offset in range(count):
        seed = start + offset
        layout = layouts[offset % len(layouts)]
        page = page_image(seed, layout)
        for label, angle in enumerate(ANGLES):
            yield f"{layout}-{seed}-{angle}", rotate(page, angle), label


def main():
    train = list((features(image), label) for _, image, label in examples(
        100, 150, ("train_report", "train_notes", "train_exercise")))
    samples, labels = map(np.asarray, zip(*train))
    np.savez_compressed(MODEL_PATH, samples=samples, labels=labels)
    model = OrientationModel(samples, labels)
    matrix = np.zeros((4, 4), dtype=int)
    rows = []
    for name, image, label in examples(1000, 48, ("test_summary", "test_tasks", "test_sparse", "test_diagram")):
        predicted, confidence = model.predict(image)
        matrix[label, ANGLES.index(predicted)] += 1
        rows.append((name, ANGLES[label], predicted, round(confidence, 3)))
    correct = int(matrix.trace())
    summary = {
        "synthetic": True, "train_base_pages": 150, "test_base_pages": 48,
        "train_images": len(train), "test_images": len(rows),
        "angles": list(ANGLES), "correct": correct, "accuracy": correct / len(rows),
        "baseline_accuracy": float(matrix[0].sum() / len(rows)),
        "confusion_matrix": matrix.tolist(),
    }
    (ROOT / "evaluation.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    with (ROOT / "predictions.csv").open("w", encoding="utf-8", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(("synthetic_id", "expected_angle", "predicted_angle", "vote_share"))
        writer.writerows(rows)
    demo = ROOT / "demo"
    demo.mkdir(exist_ok=True)
    for name, seed, layout, angle in (
        ("01-upright", 3000, "test_summary", 0),
        ("02-sideways", 3001, "test_tasks", 90),
        ("03-upside-down", 3002, "test_summary", 180),
    ):
        rotate(page_image(seed, layout, clean=True), angle).save(demo / f"{name}.png")
    page_image(3003, "test_tasks", clean=True).filter(ImageFilter.GaussianBlur(4)).save(demo / "04-blurry.png")
    page_image(3004, "test_sparse", clean=True).save(demo / "05-sparse.png")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
