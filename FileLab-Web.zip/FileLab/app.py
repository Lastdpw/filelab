"""FileLab desktop interface. Uploaded files stay on the computer."""

import math
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from PIL import ImageTk

from documents import (MAX_PAGES, MIB, Page, create_pdf, image_bytes, on_white,
                       page_range, quality_notes, read_pages, save_new)
from orientation import OrientationModel


ROOT = Path(__file__).resolve().parent
MODES = {
    "Жоғары сапа": "original",
    "Орташа": "standard",
    "Шағын файл": "small",
}
BG = "#edf2f5"
INK = "#152a3a"
MUTED = "#496373"
TEAL = "#006c61"


def file_size(data: bytes) -> str:
    return f"{len(data) / MIB:.2f} МиБ ({len(data) / 1024:.1f} КиБ)"


class FileLab:
    def __init__(self, window: tk.Tk):
        self.window = window
        self.pages: list[Page] = []
        self.source_paths: set[Path] = set()
        self.exports: dict[str, bytes] = {}
        self.model = OrientationModel.load()
        self.photo = None
        self.drag_from = None

        window.title("FileLab · Файл шеберханасы")
        window.geometry("1120x760")
        window.minsize(1000, 710)
        window.configure(bg=BG)
        style = ttk.Style(window)
        style.theme_use("clam")
        style.configure("TButton", font=("Segoe UI", 10), padding=(9, 7))
        style.configure("Accent.TButton", background=TEAL, foreground="white", borderwidth=0)
        style.map("Accent.TButton", background=[("active", "#00534a")])
        style.configure("TEntry", padding=6)
        style.configure("TCombobox", padding=6)

        header = tk.Frame(window, bg=INK, padx=23, pady=15)
        header.pack(fill="x")
        self.label(header, "FileLab", 25, "white", INK, bold=True).pack(side="left")
        self.label(header, "Студенттің файл шеберханасы", 12, "#c5dce4", INK).pack(side="left", padx=16)
        self.label(header, "ЖЕРГІЛІКТІ ӨҢДЕУ", 9, "#8fe3cb", INK, bold=True).pack(side="right")

        toolbar = tk.Frame(window, bg=BG, padx=16, pady=13)
        toolbar.pack(fill="x")
        self.button(toolbar, "+ Файл қосу", self.choose_files, accent=True).pack(side="left")
        self.button(toolbar, "Демо беттер", self.demo).pack(side="left", padx=6)
        self.button(toolbar, "Бағытты анықтау", self.auto_rotate).pack(side="left", padx=6)
        self.button(toolbar, "Сапаны тексеру", self.check_quality).pack(side="left", padx=6)
        self.button(toolbar, "Барлығын тазарту", self.clear).pack(side="right")

        body = tk.Frame(window, bg=BG, padx=16)
        body.pack(fill="both", expand=True)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)
        left = tk.Frame(body, bg="white", padx=12, pady=12)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self.label(left, "Беттер", 14, bold=True).pack(anchor="w")
        self.label(left, "Ретін өзгерту үшін сүйреңіз", 9, MUTED).pack(anchor="w", pady=(2, 8))
        list_frame = tk.Frame(left, bg="white")
        list_frame.pack(fill="both", expand=True)
        self.listbox = tk.Listbox(list_frame, width=27, height=10, font=("Segoe UI", 10),
                                  relief="flat", bg="#f1f6f7", fg=INK, selectbackground=TEAL,
                                  selectforeground="white", activestyle="none", exportselection=False)
        scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=scroll.set)
        self.listbox.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.listbox.bind("<<ListboxSelect>>", lambda _: self.show_preview())
        self.listbox.bind("<ButtonPress-1>", self.drag_start)
        self.listbox.bind("<ButtonRelease-1>", self.drag_finish)
        order = tk.Frame(left, bg="white")
        order.pack(fill="x", pady=(10, 0))
        self.button(order, "↑", lambda: self.shift(-1)).pack(side="left")
        self.button(order, "↓", lambda: self.shift(1)).pack(side="left", padx=4)
        self.button(order, "Өшіру", self.delete).pack(side="right")

        center = tk.Frame(body, bg="white", padx=12, pady=12)
        center.grid(row=0, column=1, sticky="nsew", padx=(0, 10))
        self.label(center, "Алдын ала қарау", 14, bold=True).pack(anchor="w")
        self.detail = tk.StringVar(value="Файл қосыңыз немесе демо беттерді ашыңыз.")
        self.preview = tk.Label(center, bg="#dfe9ee", fg=MUTED, font=("Segoe UI", 11), text="Бет көрінісі")
        self.preview.pack(fill="both", expand=True, pady=8)
        self.preview_timer = None
        self.preview.bind("<Configure>", self.resize_preview)
        tk.Label(center, textvariable=self.detail, bg="white", fg=MUTED, anchor="w", justify="left",
                 wraplength=420, font=("Segoe UI", 10)).pack(fill="x")
        edit = tk.Frame(center, bg="white")
        edit.pack(fill="x", pady=(7, 0))
        self.button(edit, "↺ 90°", lambda: self.rotate_selected(-90)).pack(side="left")
        self.button(edit, "↻ 90°", lambda: self.rotate_selected(90)).pack(side="left", padx=5)
        self.button(edit, "Бетті JPG/PNG сақтау", self.export_image).pack(side="right")

        right = tk.Frame(body, bg="white", padx=14, pady=12)
        right.grid(row=0, column=2, sticky="nsew")
        self.label(right, "PDF дайындау", 14, bold=True).pack(anchor="w")
        self.label(right, "Бет аралығы", 10, bold=True).pack(anchor="w", pady=(11, 2))
        self.range = tk.StringVar()
        ttk.Entry(right, textvariable=self.range, width=27).pack(fill="x")
        self.label(right, "Бос болса: барлық бет. Үлгі: 1, 3-5", 9, MUTED).pack(anchor="w", pady=(3, 0))
        self.label(right, "Сапа режимі", 10, bold=True).pack(anchor="w", pady=(11, 2))
        self.mode = tk.StringVar(value="Жоғары сапа")
        ttk.Combobox(right, textvariable=self.mode, values=list(MODES), state="readonly", width=25).pack(fill="x")
        self.label(right, "Орташа және шағын режимдер\nPDF беттерін суретке айналдырады.",
                   9, MUTED).pack(anchor="w", pady=(4, 0))
        self.label(right, "Тапсыру шегі, МиБ", 10, bold=True).pack(anchor="w", pady=(11, 2))
        self.limit = tk.StringVar(value="5")
        ttk.Entry(right, textvariable=self.limit, width=27).pack(fill="x")
        self.button(right, "Көлемдерді салыстыру", self.compare_sizes).pack(fill="x", pady=(10, 5))
        self.size_text = tk.StringVar(value="Үш режимнің нақты көлемін\nосы жерден көресіз.")
        tk.Label(right, textvariable=self.size_text, bg="#edf6f5", fg=INK, font=("Segoe UI", 9),
                 justify="left", anchor="w", padx=8, pady=7, wraplength=235).pack(fill="x", pady=(0, 8))
        self.button(right, "PDF сақтау", self.export_pdf, accent=True).pack(fill="x")
        self.range.trace_add("write", lambda *_: self.invalidate())
        self.limit.trace_add("write", lambda *_: self.show_sizes())

        self.status = tk.StringVar(value="JPG, PNG немесе PDF қосып бастаңыз.")
        tk.Label(window, textvariable=self.status, bg=BG, fg=MUTED, font=("Segoe UI", 10),
                 anchor="w", padx=17, pady=9).pack(fill="x", side="bottom")

    @staticmethod
    def label(parent, text, size, color=INK, background="white", bold=False):
        return tk.Label(parent, text=text, bg=background, fg=color, anchor="w", justify="left",
                        font=("Segoe UI", size, "bold" if bold else "normal"))

    @staticmethod
    def button(parent, text, command, accent=False):
        return ttk.Button(parent, text=text, command=command, style="Accent.TButton" if accent else "TButton")

    def selected(self) -> int | None:
        selection = self.listbox.curselection()
        return int(selection[0]) if selection else None

    def refresh(self, selected=0):
        self.listbox.delete(0, tk.END)
        for number, page in enumerate(self.pages, start=1):
            marker = " !" if page.note else ""
            self.listbox.insert(tk.END, f"{number:02}. {page.title}{marker}")
        if self.pages:
            self.listbox.selection_set(selected)
            self.listbox.see(selected)
        self.show_preview()

    def resize_preview(self, _event):
        if self.preview_timer is not None:
            self.window.after_cancel(self.preview_timer)
        self.preview_timer = self.window.after(120, self.show_preview)

    def show_preview(self):
        if self.preview_timer is not None:
            self.window.after_cancel(self.preview_timer)
            self.preview_timer = None
        index = self.selected()
        if index is None:
            self.photo = None
            self.preview.configure(image="", text="Бет көрінісі")
            self.detail.set("Файл қосыңыз немесе демо беттерді ашыңыз.")
            return
        page = self.pages[index]
        self.detail.set(f"{page.title}  ·  бұрылыс {page.rotation}°" + (f"\n{page.note}" if page.note else ""))
        try:
            image = page.image(700)
            image.thumbnail((max(30, self.preview.winfo_width() - 16), max(30, self.preview.winfo_height() - 16)))
            self.photo = ImageTk.PhotoImage(on_white(image), master=self.window)
            self.preview.configure(image=self.photo, text="")
        except Exception as error:
            self.preview.configure(image="", text="Бұл бетті көрсету мүмкін болмады")
            self.status.set(str(error))

    def choose_files(self):
        names = filedialog.askopenfilenames(title="Суреттер мен PDF таңдаңыз",
                                            filetypes=[("Суреттер мен PDF", "*.jpg *.jpeg *.png *.pdf")])
        self.add_files(Path(name) for name in names)

    def demo(self):
        self.add_files(sorted((ROOT / "demo").glob("0[1-4]-*.png")))

    def add_files(self, paths):
        errors = []
        previous = len(self.pages)
        total_bytes = sum({id(page.data): len(page.data) for page in self.pages}.values())
        for path in paths:
            try:
                if total_bytes + path.stat().st_size > 96 * MIB:
                    raise ValueError("Жобадағы файлдардың жалпы шегі — 96 МиБ.")
                added = read_pages(path)
                if len(self.pages) + len(added) > MAX_PAGES:
                    raise ValueError(f"Бір жобаға ең көбі {MAX_PAGES} бет қосылады.")
                self.pages.extend(added)
                self.source_paths.add(added[0].path)
                total_bytes += len(added[0].data)
            except Exception as error:
                errors.append(f"{path.name}: {error}")
        if len(self.pages) > previous:
            self.invalidate()
            self.refresh(previous)
            self.status.set(f"{len(self.pages) - previous} бет қосылды. Барлығы {len(self.pages)} бет.")
        if errors:
            messagebox.showwarning("Кей файлдар ашылмады", "\n".join(errors), parent=self.window)

    def drag_start(self, event):
        self.drag_from = self.listbox.nearest(event.y) if self.pages else None

    def drag_finish(self, event):
        if self.drag_from is not None and self.pages:
            self.move(self.drag_from, self.listbox.nearest(event.y))
        self.drag_from = None

    def shift(self, offset):
        index = self.selected()
        if index is not None:
            self.move(index, index + offset)

    def move(self, start, end):
        if start != end and 0 <= end < len(self.pages):
            self.pages.insert(end, self.pages.pop(start))
            self.invalidate()
            self.refresh(end)

    def delete(self):
        index = self.selected()
        if index is not None:
            self.pages.pop(index)
            self.invalidate()
            self.refresh(max(0, min(index, len(self.pages) - 1)))
            self.status.set(f"Қалғаны: {len(self.pages)} бет.")

    def clear(self):
        self.pages.clear()
        self.invalidate()
        self.refresh()
        self.status.set("Беттер тізімі тазартылды.")

    def rotate_selected(self, angle):
        index = self.selected()
        if index is not None:
            self.pages[index].rotation = (self.pages[index].rotation + angle) % 360
            self.invalidate()
            self.show_preview()

    def auto_rotate(self):
        if not self.pages:
            self.status.set("Алдымен суреттерді қосыңыз.")
            return
        changed, uncertain = 0, 0
        for page in self.pages:
            if page.index is not None:
                continue
            try:
                image = on_white(page.image(600))
                histogram = image.convert("L").histogram()
                dark_fraction = sum(histogram[:165]) / (image.width * image.height)
                if dark_fraction < 0.017:
                    uncertain += 1
                    continue
                angle, confidence = self.model.predict(image)
                if confidence < 0.65:
                    uncertain += 1
                elif angle:
                    page.rotation = (page.rotation - angle) % 360
                    changed += 1
            except Exception:
                uncertain += 1
        if changed:
            self.invalidate()
        self.show_preview()
        self.status.set(f"Суреттердің бағыты тексерілді. {changed} бет бұрылды. {uncertain} бетті қолмен қарап шығыңыз.")

    def check_quality(self):
        marked = 0
        for page in self.pages:
            try:
                page.note = ", ".join(quality_notes(page.image(500)))
                marked += bool(page.note)
            except Exception:
                page.note = "Бетті талдау мүмкін болмады"
                marked += 1
        self.refresh(self.selected() or 0)
        self.status.set(f"Сапа тексерілді. {marked} бет белгіленді.")

    def invalidate(self):
        self.exports.clear()
        self.show_sizes()

    def size_limit(self) -> float | None:
        value = self.limit.get().strip().replace(",", ".")
        if not value:
            return None
        try:
            limit = float(value)
        except ValueError:
            limit = 0
        if not math.isfinite(limit) or limit <= 0:
            raise ValueError("Көлем шегін оң сан түрінде жазыңыз.")
        return limit * MIB

    def show_sizes(self):
        if not self.exports:
            self.size_text.set("Үш режимнің нақты көлемін\nосы жерден көресіз.")
            return
        try:
            limit = self.size_limit()
        except ValueError as error:
            self.size_text.set(str(error))
            return
        lines = []
        for label, mode in MODES.items():
            if mode in self.exports:
                data = self.exports[mode]
                fit = "" if limit is None else (" · шекке сыяды" if len(data) <= limit else " · шектен асады")
                lines.append(f"{label}\n{file_size(data)}{fit}")
        self.size_text.set("\n".join(lines))

    def pdf_data(self, mode):
        if mode not in self.exports:
            pages = [self.pages[index] for index in page_range(self.range.get(), len(self.pages))]
            self.exports[mode] = create_pdf(pages, mode)
        return self.exports[mode]

    def compare_sizes(self):
        try:
            limit = self.size_limit()
            self.status.set("Үш PDF нұсқасы дайындалып жатыр…")
            self.window.update_idletasks()
            for mode in MODES.values():
                self.pdf_data(mode)
            self.show_sizes()
            recommendation = next((name for name, mode in MODES.items()
                                   if limit is None or len(self.exports[mode]) <= limit), None)
            if recommendation:
                self.mode.set(recommendation)
                self.status.set(f"Таңдалған режим: {recommendation}.")
            else:
                self.status.set("Үш нұсқа да көлем шегінен асады. Бет аралығын өзгертіңіз.")
        except Exception as error:
            self.error(error)

    def export_pdf(self):
        try:
            limit = self.size_limit()
            data = self.pdf_data(MODES[self.mode.get()])
            self.show_sizes()
            if limit is not None and len(data) > limit and not messagebox.askyesno(
                "Көлем шегі", f"Файл {file_size(data)} және берілген шектен асады. Сақтайсыз ба?", parent=self.window
            ):
                return
            name = filedialog.asksaveasfilename(defaultextension=".pdf", initialfile="FileLab.pdf",
                                                filetypes=[("PDF", "*.pdf")], parent=self.window)
            if name:
                path = Path(name)
                if path.suffix.lower() != ".pdf":
                    raise ValueError("Файлды .pdf кеңейтімімен сақтаңыз.")
                save_new(path, data, self.source_paths)
                self.status.set(f"Сақталды: {path.name} · {file_size(data)}.")
        except Exception as error:
            self.error(error)

    def export_image(self):
        index = self.selected()
        if index is None:
            self.status.set("Алдымен сақтайтын бетті таңдаңыз.")
            return
        name = filedialog.asksaveasfilename(defaultextension=".png", initialfile=f"page-{index + 1}.png",
                                           filetypes=[("PNG", "*.png"), ("JPG", "*.jpg")], parent=self.window)
        if name:
            try:
                path = Path(name)
                if path.suffix.lower() not in {".png", ".jpg", ".jpeg"}:
                    raise ValueError(".png немесе .jpg кеңейтімін таңдаңыз.")
                data = image_bytes(self.pages[index], path.suffix)
                save_new(path, data, self.source_paths)
                self.status.set(f"Сақталды: {path.name} · {file_size(data)}.")
            except Exception as error:
                self.error(error)

    def error(self, error):
        self.status.set(str(error))
        messagebox.showerror("FileLab", str(error), parent=self.window)


if __name__ == "__main__":
    root = tk.Tk()
    FileLab(root)
    root.mainloop()
