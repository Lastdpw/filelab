"""Exercise the desktop actions and check the files the app produces."""

from io import BytesIO
from pathlib import Path
from tkinter import Tk
from unittest.mock import patch

from PIL import Image
from pypdf import PdfReader
from reportlab.pdfgen.canvas import Canvas

from app import FileLab
from documents import MIB, create_pdf, page_range, read_pages, save_new
from orientation import OrientationModel, rotate
from train import page_image


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / ".verify"


def main():
    OUTPUT.mkdir(exist_ok=True)
    root = Tk()
    root.withdraw()
    try:
        app = FileLab(root)
        app.demo()
        assert len(app.pages) == 4
        app.auto_rotate()
        assert [page.rotation for page in app.pages[:3]] == [0, 270, 180]
        app.check_quality()
        assert not app.pages[0].note and "Бұлыңғыр" in app.pages[3].note
        app.refresh(3)
        app.delete()
        app.move(2, 0)
        assert app.pages[0].title == "03-upside-down.png"

        app.compare_sizes()
        sizes = {name: len(data) for name, data in app.exports.items()}
        assert len(sizes) == 3 and sizes["small"] < sizes["original"]
        app.limit.set(str((sizes["small"] + sizes["original"]) / (2 * MIB)))
        app.compare_sizes()
        assert app.mode.get() != "Жоғары сапа"
        assert "шектен асады" in app.size_text.get() and "шекке сыяды" in app.size_text.get()

        final = OUTPUT / "FileLab-demo.pdf"
        with patch("app.filedialog.asksaveasfilename", return_value=str(final)):
            app.export_pdf()
        exported = read_pages(final)
        assert len(exported) == 3
        assert all(page.image(330).height > page.image(330).width for page in exported)
        with patch("app.filedialog.asksaveasfilename", return_value=str(OUTPUT / "page-1.png")):
            app.export_image()
        with patch("app.filedialog.asksaveasfilename", return_value=str(OUTPUT / "page-1.jpg")):
            app.export_image()
        for suffix, kind in (("png", "PNG"), ("jpg", "JPEG")):
            with Image.open(OUTPUT / f"page-1.{suffix}") as image:
                assert image.format == kind and image.height > image.width

        vector = OUTPUT / "text-source.pdf"
        canvas = Canvas(str(vector))
        canvas.drawString(80, 750, "FILELAB SELECTABLE TEXT")
        canvas.showPage()
        canvas.save()
        original = app.pages[0].path.read_bytes()
        try:
            save_new(app.pages[0].path, b"unexpected", app.source_paths)
        except ValueError:
            assert app.pages[0].path.read_bytes() == original
        else:
            raise AssertionError("Export must protect its source file")
        app.add_files([vector])
        app.range.set("4, 1-2")
        split = PdfReader(BytesIO(app.pdf_data("original")))
        assert len(split.pages) == 3
        assert "FILELAB SELECTABLE TEXT" in split.pages[0].extract_text()
        assert not split.pages[1].extract_text().strip()
        app.range.set("2")
        assert len(PdfReader(BytesIO(app.pdf_data("original"))).pages) == 1
        assert page_range("3, 1-2, 2", 4) == [2, 0, 1]

        for expected, path in zip((0, 90, 180), sorted((ROOT / "demo").glob("0[1-3]-*.png"))):
            image = read_pages(path)[0].image(600).convert("RGB")
            predicted, vote = app.model.predict(image)
            assert expected == predicted
            print(f"{path.name}: expected={expected}, predicted={predicted}, vote={vote:.3f}")
        error = rotate(page_image(1003, "test_diagram"), 0)
        predicted, vote = OrientationModel.load().predict(error)
        assert predicted != 0
        print(f"test_diagram-1003-0: expected=0, predicted={predicted}, vote={vote:.3f}")
        print("PDF sizes in bytes:", sizes)
        print("OK: rotate, reorder, blur check, size limit, PDF/JPG/PNG export, merge and split")
    finally:
        root.destroy()


if __name__ == "__main__":
    main()
